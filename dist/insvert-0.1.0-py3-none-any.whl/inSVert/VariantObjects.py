from abc import ABC, abstractmethod

'''
Structural Variant Objects used to build a VCF file
'''

class StructuralVariant(ABC):
    
    def __init__(self, chrom:str, pos:int, length:int, id:str, genotype:str, ref_base:str, alt_seq:str=None, ref_seq:str=None):
        self.chrom = chrom
        self.pos = pos
        self.length = length
        self.id = id 
        self.genotype = genotype
        self.ref = ref_seq if ref_seq is not None else ref_base
        self.alt_seq = alt_seq
        self.qual = "."
        self.filter = "PASS"
        
    @abstractmethod
    def get_alt(self) -> str:
        #return the alt field
        pass

    @abstractmethod
    def get_end(self) -> str:
        # each svtype processes END differently
        pass

    @abstractmethod
    def get_info(self) -> str:
        #return the info field
        pass

    def format(self) -> str:
        #formats information into a VCF line
        alt = self.get_alt()
        info = self.get_info()
        return f"{self.chrom}\t{self.pos}\t{self.id}\t{self.ref}\t{alt}\t{self.qual}\t{self.filter}\t{info}\tGT\t{self.genotype}"
        

class Insertion(StructuralVariant):

    def __init__(self, chrom, pos, length, id, genotype, ref_base, alt_seq=None):
        super().__init__(chrom, pos, length, id, genotype, ref_base, alt_seq=alt_seq)

    def get_alt(self):
        if self.alt_seq is not None:
            return self.alt_seq
        return "<INS>"
    
    def get_end(self):
        return self.pos
    
    def get_info(self):
        END = self.get_end()
        return f"SVTYPE=INS;SVLEN={self.length};END={END}"



class Deletion(StructuralVariant):

    def __init__(self, chrom, pos, length, id, genotype, ref_base, alt_seq=None, ref_seq=None):
        if length>= 0:
            raise ValueError(f"Deletion length must be negative, got {length} instead")
        super().__init__(chrom, pos, length, id, genotype, ref_base, alt_seq=alt_seq, ref_seq=ref_seq)

    def get_alt(self):
        if self.alt_seq is not None:
            return self.alt_seq
        return "<DEL>"
    
    def get_end(self):
        return self.pos + abs(self.length)

    def get_info(self):
        END = self.get_end()
        return f"SVTYPE=DEL;SVLEN={self.length};END={END}"
    


class Inversion(StructuralVariant):

    def __init__(self, chrom, pos, length, id, genotype, ref_base, alt_seq=None, ref_seq=None):
        super().__init__(chrom, pos, length, id, genotype, ref_base, alt_seq=alt_seq, ref_seq=ref_seq)

    def get_alt(self):
        if self.alt_seq is not None:
            return self.alt_seq
        return "<INV>"

    def get_end(self):
        return self.pos + self.length

    def get_info(self):
        END = self.get_end()
        return f"SVTYPE=INV;SVLEN={self.length};END={END}"
    


class Duplication(StructuralVariant):

    def __init__(self, chrom, pos, length, id, genotype, ref_base, copy_number:int, alt_seq=None, ref_seq=None):
        super().__init__(chrom, pos, length, id, genotype, ref_base, alt_seq=alt_seq, ref_seq=ref_seq)
        self.copy_number = copy_number

    def get_alt(self):
        if self.alt_seq is not None:
            return self.alt_seq
        return "<DUP>"
    
    def get_end(self):
        return self.pos + self.length

    def get_info(self):
        END = self.get_end()
        return f"SVTYPE=DUP;SVLEN={self.length};END={END}"
    
    def format(self) -> str:
        #overrides the format method of the parent class : adds details of DUPs 
        alt = self.get_alt()
        info = self.get_info()
        return f"{self.chrom}\t{self.pos}\t{self.id}\t{self.ref}\t{alt}\t{self.qual}\t{self.filter}\t{info}\tGT:CN\t{self.genotype}:{self.copy_number}"
    


class Breakend(StructuralVariant):
    """
    Represents a single BND record in VCF 4.2.
    """
    def __init__(self, chrom, pos, id, genotype, mate_id, event_id, alt_string, ref_base):
        # Length is typically 0 or 1 for BNDs as they represent a single point junction
        super().__init__(chrom, pos, 0, id, genotype, ref_base)
        self.mate_id = mate_id
        self.event_id = event_id
        self.alt_string = alt_string # The bracketed ALT string (e.g., N[chr2:5000[)

    def get_alt(self):
        """Returns the specific bracketed ALT string for this breakend."""
        return self.alt_string

    def get_end(self):
        """For BNDs, the END is the same as the POS."""
        return self.pos

    def get_info(self):
        """
        Returns the INFO field including BND-specific tags.
        """
        # We include MATEID to link to the partner BND and EVENT to group all 4.
        # TRA_ROLE helps the simulation engine know if it's cutting or pasting.
        return (f"SVTYPE=BND;MATEID={self.mate_id};"
                f"EVENT={self.event_id}")

    def format(self):
        """Overrides format to ensure SVLEN is not typically included for BNDs."""
        alt = self.get_alt()
        info = self.get_info()
        return (f"{self.chrom}\t{self.pos}\t{self.id}\t{self.ref}\t{alt}\t"
                f"{self.qual}\t{self.filter}\t{info}\tGT\t{self.genotype}")


class Polymorphism:
    """Represents an SNP or MNP in VCF 4.2 format."""

    def __init__(self, chrom: str, pos: int, id: str, genotype: str, ref_seq: str, alt_seq: str):
        if not ref_seq or not alt_seq:
            raise ValueError("Polymorphism REF and ALT sequences must not be empty")
        if len(ref_seq) != len(alt_seq):
            raise ValueError("Polymorphism REF and ALT sequences must have equal lengths")

        self.chrom = chrom
        self.pos = pos
        self.id = id
        self.genotype = genotype
        self.ref = ref_seq
        self.alt = alt_seq
        self.variant_type = "SNP" if len(ref_seq) == 1 else "MNP"
        self.qual = "."
        self.filter = "PASS"

    def get_end(self) -> int:
        """Return the 1-indexed inclusive end position."""
        return self.pos + len(self.ref) - 1

    def format(self) -> str:
        """Format the polymorphism as an explicit VCF record."""
        return (f"{self.chrom}\t{self.pos}\t{self.id}\t{self.ref}\t{self.alt}\t"
                f"{self.qual}\t{self.filter}\tVT={self.variant_type}\tGT\t{self.genotype}")







